package com.flymaccin.hyphypixels;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
        setContentView(new GameView(this));
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }

    private static final class GameView extends View {
        private static final int READY = 0;
        private static final int RUNNING = 1;
        private static final int PAUSED = 2;
        private static final int GAME_OVER = 3;

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random random = new Random();
        private final ArrayList<FallingObject> objects = new ArrayList<>();
        private final ArrayList<Spark> sparks = new ArrayList<>();
        private final SharedPreferences prefs;

        private int state = READY;
        private int lane = 0;
        private int score = 0;
        private int highScore;
        private int collected = 0;
        private float scoreFloat = 0f;
        private float elapsed = 0f;
        private float spawnTimer = 0.3f;
        private long lastFrameMs = 0L;
        private float downX;
        private float downY;

        private int w;
        private int h;
        private float unit;
        private float playerY;
        private float laneLeft;
        private float laneRight;
        private final RectF playerRect = new RectF();

        GameView(Context context) {
            super(context);
            setFocusable(true);
            setKeepScreenOn(true);
            prefs = context.getSharedPreferences("hyphy_pixels", Context.MODE_PRIVATE);
            highScore = prefs.getInt("high_score", 0);
            textPaint.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
        }

        @Override
        protected void onSizeChanged(int width, int height, int oldw, int oldh) {
            w = width;
            h = height;
            unit = Math.min(w, h) / 100f;
            laneLeft = w * 0.32f;
            laneRight = w * 0.68f;
            playerY = h * 0.82f;
            sparks.clear();
            for (int i = 0; i < 44; i++) {
                sparks.add(new Spark(
                        random.nextFloat() * w,
                        random.nextFloat() * h,
                        0.6f + random.nextFloat() * 2.3f,
                        10f + random.nextFloat() * 42f
                ));
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = SystemClock.elapsedRealtime();
            float dt = lastFrameMs == 0L ? 0f : Math.min(0.05f, (now - lastFrameMs) / 1000f);
            lastFrameMs = now;

            if (state == RUNNING && dt > 0f) {
                update(dt);
            } else if (dt > 0f) {
                updateBackground(dt * 0.35f);
            }

            drawBackground(canvas);
            drawTrack(canvas);
            drawObjects(canvas);
            drawPlayer(canvas);
            drawHud(canvas);
            drawOverlay(canvas);

            postInvalidateOnAnimation();
        }

        private void update(float dt) {
            elapsed += dt;
            scoreFloat += dt * 11f;
            score = (int) scoreFloat + collected * 25;
            updateBackground(dt);

            spawnTimer -= dt;
            if (spawnTimer <= 0f) {
                spawnObject();
                float interval = Math.max(0.34f, 0.78f - elapsed * 0.0065f);
                spawnTimer = interval * (0.82f + random.nextFloat() * 0.36f);
            }

            float speed = h * Math.min(0.78f, 0.34f + elapsed * 0.0062f);
            float playerHalf = 5.4f * unit;
            float playerX = lane == 0 ? laneLeft : laneRight;
            playerRect.set(
                    playerX - playerHalf,
                    playerY - playerHalf,
                    playerX + playerHalf,
                    playerY + playerHalf
            );

            Iterator<FallingObject> iterator = objects.iterator();
            while (iterator.hasNext()) {
                FallingObject obj = iterator.next();
                obj.y += speed * dt;
                float half = obj.kind == FallingObject.COIN ? 3.7f * unit : 5.1f * unit;
                RectF r = new RectF(obj.x - half, obj.y - half, obj.x + half, obj.y + half);

                if (RectF.intersects(playerRect, r)) {
                    if (obj.kind == FallingObject.COIN) {
                        collected++;
                        burst(obj.x, obj.y, true);
                        iterator.remove();
                    } else {
                        burst(playerX, playerY, false);
                        iterator.remove();
                        endGame();
                        break;
                    }
                } else if (obj.y > h + 8f * unit) {
                    iterator.remove();
                }
            }

            Iterator<Spark> sparkIterator = sparks.iterator();
            while (sparkIterator.hasNext()) {
                Spark s = sparkIterator.next();
                s.y += s.speed * dt;
                if (s.burst) {
                    s.life -= dt;
                    s.x += s.vx * dt;
                    if (s.life <= 0f) {
                        sparkIterator.remove();
                    }
                } else if (s.y > h + 4f * unit) {
                    s.y = -4f * unit;
                    s.x = random.nextFloat() * w;
                }
            }
        }

        private void updateBackground(float dt) {
            for (Spark s : sparks) {
                if (!s.burst) {
                    s.y += s.speed * dt;
                    if (s.y > h + 4f * unit) {
                        s.y = -4f * unit;
                        s.x = random.nextFloat() * w;
                    }
                }
            }
        }

        private void spawnObject() {
            int objLane = random.nextBoolean() ? 0 : 1;
            int kind = random.nextFloat() < 0.30f ? FallingObject.COIN : FallingObject.HAZARD;
            float x = objLane == 0 ? laneLeft : laneRight;
            objects.add(new FallingObject(x, -8f * unit, kind));
        }

        private void burst(float x, float y, boolean gold) {
            for (int i = 0; i < 12; i++) {
                float angle = (float) (random.nextFloat() * Math.PI * 2.0);
                float velocity = (18f + random.nextFloat() * 45f) * unit;
                Spark s = new Spark(x, y, 0f, 0f);
                s.burst = true;
                s.gold = gold;
                s.vx = (float) Math.cos(angle) * velocity;
                s.speed = (float) Math.sin(angle) * velocity;
                s.life = 0.25f + random.nextFloat() * 0.30f;
                s.size = 1.1f + random.nextFloat() * 1.5f;
                sparks.add(s);
            }
        }

        private void startGame() {
            state = RUNNING;
            lane = 0;
            score = 0;
            scoreFloat = 0f;
            collected = 0;
            elapsed = 0f;
            spawnTimer = 0.55f;
            objects.clear();
            lastFrameMs = SystemClock.elapsedRealtime();
        }

        private void endGame() {
            state = GAME_OVER;
            if (score > highScore) {
                highScore = score;
                prefs.edit().putInt("high_score", highScore).apply();
            }
        }

        private void drawBackground(Canvas canvas) {
            canvas.drawColor(Color.rgb(10, 4, 24));

            paint.setStyle(Paint.Style.FILL);
            for (Spark s : sparks) {
                if (s.burst) {
                    int alpha = (int) (255f * Math.max(0f, Math.min(1f, s.life / 0.55f)));
                    paint.setColor(s.gold ? Color.argb(alpha, 255, 204, 55) : Color.argb(alpha, 255, 54, 190));
                    canvas.drawRect(s.x - s.size * unit, s.y - s.size * unit,
                            s.x + s.size * unit, s.y + s.size * unit, paint);
                } else {
                    paint.setColor(Color.argb(95, 143, 76, 255));
                    canvas.drawRect(s.x, s.y, s.x + s.size * unit, s.y + s.size * unit, paint);
                }
            }

            paint.setColor(Color.argb(55, 255, 64, 197));
            canvas.drawRect(0, h * 0.16f, w, h * 0.165f, paint);
            paint.setColor(Color.argb(40, 137, 87, 255));
            canvas.drawRect(0, h * 0.63f, w, h * 0.635f, paint);
        }

        private void drawTrack(Canvas canvas) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f, 0.45f * unit));
            paint.setColor(Color.argb(115, 156, 99, 255));
            float top = h * 0.12f;
            float bottom = h * 0.93f;
            canvas.drawLine(w * 0.14f, top, w * 0.14f, bottom, paint);
            canvas.drawLine(w * 0.50f, top, w * 0.50f, bottom, paint);
            canvas.drawLine(w * 0.86f, top, w * 0.86f, bottom, paint);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(26, 255, 255, 255));
            canvas.drawRect(w * 0.145f, top, w * 0.495f, bottom, paint);
            canvas.drawRect(w * 0.505f, top, w * 0.855f, bottom, paint);
        }

        private void drawObjects(Canvas canvas) {
            for (FallingObject obj : objects) {
                if (obj.kind == FallingObject.COIN) {
                    float s = 4.0f * unit;
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(Color.rgb(255, 204, 55));
                    canvas.drawRect(obj.x - s, obj.y - s, obj.x + s, obj.y + s, paint);
                    paint.setColor(Color.rgb(83, 34, 117));
                    canvas.drawRect(obj.x - 1.2f * unit, obj.y - 1.2f * unit,
                            obj.x + 1.2f * unit, obj.y + 1.2f * unit, paint);
                } else {
                    float s = 5.2f * unit;
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(Color.rgb(255, 54, 190));
                    canvas.drawRoundRect(new RectF(obj.x - s, obj.y - s, obj.x + s, obj.y + s),
                            1.1f * unit, 1.1f * unit, paint);
                    paint.setColor(Color.rgb(25, 8, 41));
                    float stripe = 1.1f * unit;
                    canvas.drawRect(obj.x - s, obj.y - stripe, obj.x + s, obj.y + stripe, paint);
                    canvas.drawRect(obj.x - stripe, obj.y - s, obj.x + stripe, obj.y + s, paint);
                }
            }
        }

        private void drawPlayer(Canvas canvas) {
            float x = lane == 0 ? laneLeft : laneRight;
            float s = 5.4f * unit;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(65, 255, 205, 55));
            canvas.drawRoundRect(new RectF(x - s * 1.38f, playerY - s * 1.38f,
                    x + s * 1.38f, playerY + s * 1.38f), 2f * unit, 2f * unit, paint);

            paint.setColor(Color.rgb(255, 207, 58));
            canvas.drawRoundRect(new RectF(x - s, playerY - s, x + s, playerY + s),
                    1.7f * unit, 1.7f * unit, paint);
            paint.setColor(Color.rgb(88, 40, 145));
            canvas.drawRect(x - 2.0f * unit, playerY - 2.0f * unit,
                    x + 2.0f * unit, playerY + 2.0f * unit, paint);
        }

        private void drawHud(Canvas canvas) {
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(5.7f * unit);
            textPaint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("SCORE " + score, 5f * unit, 8f * unit, textPaint);

            textPaint.setColor(Color.rgb(255, 204, 55));
            textPaint.setTextSize(3.4f * unit);
            canvas.drawText("BEST " + highScore + "   GOLD " + collected, 5f * unit, 12.3f * unit, textPaint);

            float bx = w - 8f * unit;
            float by = 7.2f * unit;
            paint.setColor(Color.argb(125, 255, 255, 255));
            paint.setStrokeWidth(1.5f * unit);
            if (state == PAUSED) {
                paint.setStyle(Paint.Style.FILL);
                float[] xs = {bx - 2f * unit, bx - 2f * unit, bx + 2.5f * unit};
                float[] ys = {by - 2.5f * unit, by + 2.5f * unit, by};
                android.graphics.Path path = new android.graphics.Path();
                path.moveTo(xs[0], ys[0]);
                path.lineTo(xs[1], ys[1]);
                path.lineTo(xs[2], ys[2]);
                path.close();
                canvas.drawPath(path, paint);
            } else {
                paint.setStyle(Paint.Style.FILL);
                canvas.drawRect(bx - 2.8f * unit, by - 2.6f * unit,
                        bx - 0.8f * unit, by + 2.6f * unit, paint);
                canvas.drawRect(bx + 0.8f * unit, by - 2.6f * unit,
                        bx + 2.8f * unit, by + 2.6f * unit, paint);
            }
        }

        private void drawOverlay(Canvas canvas) {
            if (state == RUNNING) {
                return;
            }

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(state == READY ? 55 : 135, 4, 0, 12));
            canvas.drawRect(0, 0, w, h, paint);

            textPaint.setTextAlign(Paint.Align.CENTER);
            if (state == READY) {
                textPaint.setColor(Color.rgb(255, 204, 55));
                textPaint.setTextSize(9.2f * unit);
                canvas.drawText("HYPHY", w / 2f, h * 0.35f, textPaint);
                textPaint.setColor(Color.rgb(255, 54, 190));
                canvas.drawText("PIXELS", w / 2f, h * 0.44f, textPaint);

                textPaint.setColor(Color.WHITE);
                textPaint.setTextSize(3.6f * unit);
                canvas.drawText("TAP TO SWITCH LANES", w / 2f, h * 0.55f, textPaint);
                canvas.drawText("GRAB GOLD. DODGE STATIC.", w / 2f, h * 0.60f, textPaint);
                textPaint.setColor(Color.rgb(186, 149, 255));
                textPaint.setTextSize(3.0f * unit);
                canvas.drawText("TAP TO START", w / 2f, h * 0.70f, textPaint);
            } else if (state == PAUSED) {
                textPaint.setColor(Color.WHITE);
                textPaint.setTextSize(8.2f * unit);
                canvas.drawText("PAUSED", w / 2f, h * 0.47f, textPaint);
                textPaint.setColor(Color.rgb(255, 204, 55));
                textPaint.setTextSize(3.3f * unit);
                canvas.drawText("TAP ▶ UP TOP TO RESUME", w / 2f, h * 0.55f, textPaint);
            } else if (state == GAME_OVER) {
                textPaint.setColor(Color.rgb(255, 54, 190));
                textPaint.setTextSize(7.7f * unit);
                canvas.drawText("STATIC GOT YOU", w / 2f, h * 0.41f, textPaint);
                textPaint.setColor(Color.WHITE);
                textPaint.setTextSize(4.8f * unit);
                canvas.drawText("SCORE " + score, w / 2f, h * 0.50f, textPaint);
                textPaint.setColor(Color.rgb(255, 204, 55));
                textPaint.setTextSize(3.6f * unit);
                canvas.drawText("BEST " + highScore, w / 2f, h * 0.56f, textPaint);
                textPaint.setColor(Color.rgb(186, 149, 255));
                textPaint.setTextSize(3.2f * unit);
                canvas.drawText("TAP TO RUN IT BACK", w / 2f, h * 0.66f, textPaint);
            }
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                downX = event.getX();
                downY = event.getY();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float x = event.getX();
                float y = event.getY();
                boolean movedTooFar = Math.abs(x - downX) > 15f * unit || Math.abs(y - downY) > 15f * unit;
                if (movedTooFar) {
                    return true;
                }

                boolean pauseZone = x > w - 18f * unit && y < 16f * unit;
                if (pauseZone && (state == RUNNING || state == PAUSED)) {
                    state = state == RUNNING ? PAUSED : RUNNING;
                    lastFrameMs = SystemClock.elapsedRealtime();
                    return true;
                }

                if (state == READY || state == GAME_OVER) {
                    startGame();
                    return true;
                }

                if (state == RUNNING) {
                    lane = lane == 0 ? 1 : 0;
                }
                return true;
            }
            return true;
        }
    }

    private static final class FallingObject {
        static final int COIN = 0;
        static final int HAZARD = 1;
        final float x;
        float y;
        final int kind;

        FallingObject(float x, float y, int kind) {
            this.x = x;
            this.y = y;
            this.kind = kind;
        }
    }

    private static final class Spark {
        float x;
        float y;
        float size;
        float speed;
        float vx;
        float life;
        boolean burst;
        boolean gold;

        Spark(float x, float y, float size, float speed) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.speed = speed;
        }
    }
}
