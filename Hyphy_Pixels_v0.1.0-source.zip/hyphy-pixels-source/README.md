# Hyphy Pixels v0.1.0

A native Android one-thumb arcade prototype for the FME game slate.

## Loop
- Tap anywhere to switch between two lanes.
- Collect gold pixels for bonus points.
- Dodge magenta static blocks.
- Speed increases over time.
- High score is stored locally on-device.
- Tap the top-right pause control to pause/resume.

## Android
- Package: `com.flymaccin.hyphypixels`
- minSdk: 23
- targetSdk: 35
- compileSdk: 35
- Java 17 / Android Gradle Plugin 8.7.3

No ads, account, analytics, network access, or external assets are used in this prototype.
