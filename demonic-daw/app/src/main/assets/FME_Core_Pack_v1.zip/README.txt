FME CORE PACK v1
240 essential FME WAV samples for Demonic DAW offline first launch.
Full 1,782-sample library remains an optional local expansion.
